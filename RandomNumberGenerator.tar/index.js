import './index.css'

import {Component} from 'react'

class RandomNumberGenerator extends Component {
  state = {randomNumber: 0}

  displayRandomNumber = () => {
    const newRandomNumber = Math.ceil(Math.random() * 100)
    this.setState({randomNumber: newRandomNumber})
  }

  render() {
    const {randomNumber} = this.state

    return (
      <div className="bg-container">
        <div className="mini-container">
          <h1 className="heading">Random Number</h1>
          <p>Generate a random number in the range of 0 to 100</p>
          <button
            className="button"
            type="button"
            onClick={this.displayRandomNumber}
          >
            Generate
          </button>
          <p className="color">{randomNumber}</p>
        </div>
      </div>
    )
  }
}
export default RandomNumberGenerator
